/* Test module for bug-dlsym1.c test case.  */

char dlopen_test_variable;
