/* Define the machine-dependent type `jmp_buf'.  Stub version.  */

#ifndef _SETJMP_H
# error "Never include <bits/setjmp.h> directly; use <setjmp.h> instead."
#endif

typedef int __jmp_buf[1];
