/* This file should define the implementation-specific limits described
   in posix[12]_lim.h.  If there are no useful values to give a limit,
   don't define it.  */
